
# FullCalendar Bootstrap Plugin

Bootstrap 4 theming for your calendar

[View the docs &raquo;](https://fullcalendar.io/docs/bootstrap-theme)

This package was created from the [FullCalendar monorepo &raquo;](https://github.com/fullcalendar/fullcalendar)
